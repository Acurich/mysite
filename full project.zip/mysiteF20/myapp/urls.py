from django.urls import path
from myapp import views
from myapp import admin

app_name = 'myapp'

urlpatterns = [
    path(r'', views.index, name='index'),
    path(r'about/', views.about, name='about'),
    path(r'findcourses/', views.findcourses, name='findcourses'),
    path(r'results/', views.findcourses, name='results'),
    path(r'placeorder/', views.place_order, name='placeorder'),
    path(r'order_response/', views.place_order, name='order_response'),
    path(r'review/', views.review, name='review'),
    path(r'login/', views.user_login, name='login'),
    path(r'logout/', views.user_logout, name='login'),
    path(r'myaccount/', views.myaccount, name='myaccount'),
    path(r'register/', views.register, name='register'),
    path(r'forgotpassword/', views.forgotpassword, name='forgotpassword'),
    path(r'registration_response/', views.register, name='registration_response'),
    path(r'forgotpassword_response/', views.forgotpassword, name='forgotpassword_response'),
    path(r'detail/<int:topic_id>', views.detail, name='detail'),
    ]
