# Import necessary classes
import datetime as dt
import string

from django.conf import settings
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import get_object_or_404, redirect
from django.shortcuts import render
from django.urls import reverse
import smtplib, ssl

from .forms import SearchForm, OrderForm, ReviewForm, loginForm, RegisterForm, PasswordForm
from .models import Topic, Course, Student, Order


# Create your views here.
def index(request):
    top_list = Topic.objects.all().order_by('id')[:10]
    last_login = ''
    if 'last_login' in request.session:
        last_login = request.session['last_login']
    else:
        last_login = 'Your last login was more than one hour ago'

    return render(request, 'myapp/index.html', {'top_list': top_list, 'last_login': last_login, 'user':User})

def about(request):
    # response = HttpResponse()
    # if 'about_visits' in request.COOKIES:
    #     numofvisits = request.COOKIES['about_visits'] + 1
    #     response.set_cookie('about_visits', numofvisits, max_age=300)
    # else:
    #     numofvisits = 0
    #     response.set_cookie('about_visits', numofvisits, max_age=300)
    # return render(request, 'myapp/about.html', {'number_of_visits': numofvisits})

    if 'about_visits' in request.session:
        request.session['about_visits'] += 1
        request.session.set_expiry(300)
    else:
        request.session['about_visits'] = 1
    return render(request, 'myapp/about.html', {'number_of_visits': request.session['about_visits']})

def detail(request, topic_id):
    topic = get_object_or_404(Topic, id=topic_id)
    course_list = Course.objects.filter(topic=Topic.objects.get(id=1))
    return render(request, 'myapp/details.html', {'topic': topic, 'course_list':course_list})

def findcourses(request):
    # breakpoint()
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            length = form.cleaned_data['length']
            max_price = form.cleaned_data['max_price']
            topics = Topic.objects.filter(length=length)
            courselist = []
            for top in topics:
                courselist = courselist + list(top.courses.all())
                #courselist = courselist + list(top.courses.all().filter(price__in=max_price))
            return render(request, 'myapp/results.html', {'courselist':courselist, 'name':name})
        else:
            return HttpResponse('Invalid data')
    else:
        form = SearchForm()
        return render(request, 'myapp/findcourses.html', {'form':form})

def place_order(request):
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            courses = form.cleaned_data['courses']
            order = form.save(commit=True)
            student = order.student
            status = order.order_status
            order.save()
            if status == 1:
                for c in order.courses.all():
                    student.registered_courses.add(c)
            return render(request, 'myapp/order_response.html', {'courses': courses, 'order':order})
        else:
            return render(request, 'myapp/place_order.html', {'form':form})

    else:
        form = OrderForm()
        return render(request, 'myapp/place_order.html', {'form':form})

@login_required(login_url='/myapp/login')
def review(request):
    user = request.user;
    students = Student.objects.filter(username=user.username)
    if len(students) == 1:
        student = students[0]
        if request.method == 'POST':
            form = ReviewForm(request.POST)
            if form.is_valid():
                rating = form.cleaned_data['rating']
                if 5 >= rating >= 1:
                    reviews = form.save(commit=False)
                    course = reviews.course
                    course.num_reviews = course.num_reviews + 1
                    reviews.save()
                    course.save()
                    return index(request)
                else:
                    error_msg = 'Error: Please Enter The Ratings Value Under 5'
                    return render(request, 'myapp/review.html', {'form': form, 'error_msg': error_msg})
            else:
                return HttpResponse('Invalid data')

        else:
            form = ReviewForm()
            return render(request, 'myapp/review.html', {'form': form})
    else:
        return render(request, 'myapp/not_a_student_review.html')
def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if request.session.test_cookie_worked():
            request.session.delete_test_cookie()
            if user:
                if user.is_active:
                    login(request, user)
                    last_login = dt.datetime.now()
                    request.session['last_login'] = str(last_login)
                    return HttpResponseRedirect(reverse('myapp:myaccount'))
                else:
                    return HttpResponse('Your account is disabled.')
            else:
                return HttpResponse('Invalid login details.')
        else:
            return HttpResponse("Please enable cookies to continue")
    else:
        request.session.set_test_cookie()
        form = loginForm()
        return render(request, 'myapp/login.html',{'form':form})

def forgotpassword(request):
    errorMsg = ''
    successMsg = ''
    if request.method == 'POST':
        form = PasswordForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            try:
                user = Student.objects.get(username=username)
                password = str(user.first_name+user.last_name)
                user.set_password(password)
                user.save()
                #sendHotmail_Mail(email,password)
                # send_mail(
                #     'Your New Password',
                #     'Your New Password is: ' + str(password),
                #     'elearningapptemp@hotmail.com',
                #     [str(email)],
                #     'smtp.office365.com',
                # )
                errorMsg = ''
                successMsg = 'Password sent successfully.'
            except Exception as e:
                errorMsg = 'No user exists with given details, Error : ' + str(e)
                successMsg = ''

            return render(request, 'myapp/fotgotPassword_response.html', {'errorMsg': errorMsg,'successMsg':successMsg})
    else:
        form = PasswordForm()
    return render(request, 'myapp/forgotpassword.html', {'form': form})

@login_required(login_url='/myapp/login')
def user_logout(request):
    logout(request)
    return HttpResponseRedirect(reverse(('myapp:index')))

@login_required(login_url='/myapp/login')
def myaccount(request):
    user = request.user;
    students = Student.objects.filter(username=user.username)
    if len(students) == 1:
        student = students[0]
        return render(request,'myapp/myaccount.html', {'first_name': student.first_name,
                                                        'last_name': student.last_name,
                                                        'courses_ordered': student.registered_courses.all(),
                                                        'topics_interested': student.interested_in.all()})
    else:
        return render(request,'myapp/not_a_student.html')

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            student = form.save(commit=True)
            student.interested_in.set(form.cleaned_data.get("interested_in"))
            student.save()
            return redirect('myapp:login')

    form = RegisterForm()
    return render(request, 'myapp/register.html', {'form': form})


def sendHotmail_Mail(sendto,password):
    uid = "elearningapptemp@hotmail.com"
    pwd = "python123"
    to = sendto
    subject = "\nSubject: Your New E-Learnin App Password"
    content = "\nYour New E-Learnig App Password is: " + password
    mail_server = 'smptp.office365.com'
    msg = "From: " + uid
    msg = msg + "\nTo: " + to
    msg = msg + subject
    msg = msg + content
    send_mail(uid, pwd, to, msg, mail_server)


def send_mail(uid, pwd, to, message, mail_server):
    server = smtplib.SMTP(mail_server, 587)
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login(uid, pwd)
    server.sendmail(uid, to,"Your New Password for E-Learning App",message)
    server.close()